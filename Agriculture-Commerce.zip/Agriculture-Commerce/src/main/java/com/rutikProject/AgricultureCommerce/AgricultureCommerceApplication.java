package com.rutikProject.AgricultureCommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgricultureCommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgricultureCommerceApplication.class, args);
	}

}
