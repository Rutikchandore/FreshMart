package com.rutikProject.AgricultureCommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgricultureCommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
